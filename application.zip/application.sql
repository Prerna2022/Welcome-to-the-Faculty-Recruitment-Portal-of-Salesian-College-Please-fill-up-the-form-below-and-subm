-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2023 at 03:19 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `candidates`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `Sno` int(3) NOT NULL,
  `Name` text NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` text NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Address` text NOT NULL,
  `Department` text NOT NULL,
  `10Board` text NOT NULL,
  `10PassYear` int(4) NOT NULL,
  `10Percentage` float NOT NULL,
  `12Board` text NOT NULL,
  `12PassYear` int(4) NOT NULL,
  `12Percentage` float NOT NULL,
  `GUniversity` text NOT NULL,
  `GCollege` text NOT NULL,
  `GPassYear` int(4) NOT NULL,
  `GPercentage` float NOT NULL,
  `PGUniversity` text NOT NULL,
  `PGPassYear` int(4) NOT NULL,
  `PGPercentage` float NOT NULL,
  `NET` text NOT NULL,
  `PHD` text NOT NULL,
  `Publication` int(11) NOT NULL,
  `Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`Sno`, `Name`, `Age`, `Gender`, `Phone`, `email`, `Address`, `Department`, `10Board`, `10PassYear`, `10Percentage`, `12Board`, `12PassYear`, `12Percentage`, `GUniversity`, `GCollege`, `GPassYear`, `GPercentage`, `PGUniversity`, `PGPassYear`, `PGPercentage`, `NET`, `PHD`, `Publication`, `Date`) VALUES
(1, 'Ayush Anand', 25, 'Male', '9973727102', 'ayushand7@gmail.com', 'Kasba, Purnia, Bihar', 'Computer Science & Application', 'ICSE', 2012, 94.8, 'CBSE', 2014, 73, 'University of North Bengal', 'Salesian College Siliguri', 2020, 77.75, 'University of North Bengal', 2022, 83.8, 'No', 'No', 0, '2023-01-17 18:12:34'),
(2, 'Ankita Sen', 23, 'Female', '8617527775', 'ankitasen463@gmail.com', 'Shantinagar, Alipurduar, WB', 'Sociology', 'WBSE', 2015, 85, 'WBSE', 2017, 89, 'University of North Bengal', 'Salesian College Siliguri', 2020, 81, 'University of North Bengal', 2022, 85, 'No', 'No', 0, '2023-01-17 20:26:59'),
(3, 'Aritri Goswami', 23, 'Female', '9883838973', 'aritrigoswami@gmail.com', 'Lake Town, Siliguri, WB', 'Computer Science & Application', 'CBSE', 2015, 83, 'CBSE', 2017, 82, 'University of North Bengal', 'Siliguri College', 2020, 79, 'University of North Bengal', 2022, 81, 'No', 'No', 0, '2023-01-17 20:38:44'),
(7, 'Ritesh kumar', 28, 'Male', '8989898989', 'rk@gmail.com', 'kasba, Purnia, Bihar', 'English', 'CBSE', 2008, 91, 'CBSE', 2010, 91, 'Patna University', 'Patna College', 2013, 88, 'Patna University', 2015, 87, 'Yes', 'No', 2, '2023-01-18 23:03:23'),
(8, 'Yadhika Prasad', 25, 'Female', '7894561232', 'ydk@gmail.com', 'Don Bosco More, Siliguri, WB', 'History', 'CBSE', 2010, 86, 'CBSE', 2012, 84, 'University of North Bengal', 'Siliguri College', 2015, 88, 'University of North Bengal', 2017, 87, 'Yes', 'Yes', 5, '2023-01-19 09:40:17'),
(10, 'Amit Kumar', 23, 'Male', '8754219865', 'amk@gmail.com', 'Ranchi, Jharkhand', 'Political Science', 'CBSE', 2011, 81, 'CBSE', 2013, 83, 'BTU', 'ACC', 2016, 85, 'BTU', 2018, 83, 'Yes', 'Yes', 3, '2023-01-19 10:30:52'),
(11, 'Anup Kumar', 21, 'Male', '8527419632', 'anpkmr@gmail.com', 'Champasari, Siliguri, West Bengal', 'Physics', 'CBSE', 2012, 78, 'CBSE', 2014, 77, 'BU', 'CRC', 2017, 81, 'BU', 2019, 79, 'Yes', 'No', 0, '2023-01-19 10:34:39'),
(12, 'Prerna Prasad', 26, 'Female', '7539517534', 'pp@gmail.com', 'Khaprail, Siliguri, WB', 'Economics', 'CBSE', 2013, 77, 'CBSE', 2015, 79, 'AMU', 'ACC', 2018, 75, 'AMU', 2020, 77, 'Yes', 'No', 1, '2023-01-19 10:38:29'),
(14, 'Anirudh Ghosh', 31, 'Male', '4561237534', 'ankgsh@gmail.com', 'Haiderpara, Siliguri, WB', 'Geography', 'CBSE', 2008, 65, 'CBSE', 2010, 71, 'CU', 'St Xaviers', 2013, 76, 'CU', 2015, 77, 'Yes', 'No', 0, '2023-01-19 11:34:03'),
(17, 'Amit Biswas', 23, 'Male', '1597538524', 'amtbswas@gmail.com', 'Hakimpara, Siliguri, WB', 'Psychology', 'CBSE', 2012, 86, 'CBSE', 2014, 83, 'NBU', 'ACC', 2017, 85, 'NBU', 2019, 84, 'Yes', 'No', 0, '2023-01-19 11:40:59'),
(22, 'Tanay Badra', 25, 'Male', '7777888855', 'tanaybd@gmail.com', 'Nibu Basti, Siliguri, WB', 'Sports Management', 'CBSE', 2006, 89, 'CBSE', 2008, 83, 'BHU', 'Banaras College', 2012, 77, 'BHU', 2015, 83, 'Yes', 'No', 2, '2023-01-19 12:23:11'),
(26, 'Sourav Das', 27, 'Male', '9576779210', 'srvdas@gmail.com', 'Matigara, Siliguri, WB', 'Commerce', 'CBSE', 2011, 87, 'CBSE', 2013, 85, 'Gujarat University', 'Narendra Modi College', 2018, 88, 'Gujarat University', 2020, 83, 'Yes', 'No', 1, '2023-01-19 12:32:16'),
(27, 'Robi Khan', 25, 'Male', '1237894265', 'rbkh@gmail.com', 'Don Bosco More, Siliguri, Wb', 'English', 'CBSE', 2012, 86, 'CBSE', 2014, 91, 'NBU', 'Salesian College', 2017, 93, 'NBU', 2019, 95, 'Yes', 'No', 1, '2023-01-19 13:01:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`Sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `Sno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
