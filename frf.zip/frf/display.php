<?php
session_start();
            $server="localhost";
            $username="root";
            $password="";
            $database="candidates";
            $con= mysqli_connect($server,$username,$password,$database);
            $phone=$_SESSION['var'];
            $sql= "SELECT * FROM `application` WHERE Phone = '$phone'";
            $result = mysqli_query($con,$sql);
            $num = mysqli_num_rows($result);
            if($con->query($sql)==true){
                //echo "Successfully inserted";
                //$insert=true;
            }
            else
            {
                echo " Error: $con->error <br>";
            }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
        //echo "$phone";
        if($num>0){
            while($row=mysqli_fetch_assoc($result)){
                echo '<table border=1px><tr><td>Application Number</td><td>Name</td><td>Age</td><td>Phone</td><td>Email</td><td>Address</td><td>Class 10 Marks</td><td>Class 12 Marks</td><td>Graduation Year</td><td>Graduation University</td><td>Graduation Marks</td><td>Post Graduation Year</td><td>Post Graduation University</td><td>Post Graduation Marks</td><td>NET</td><td>PHD</td><td>Publication</td></tr><tr><td>'.$row['Sno'].'</td><td>'.$row['Name'].'</td><td>'.$row['Age'].'</td><td>'.$row['Phone'].'</td><td>'.$row['email'].'</td><td>'.$row['Address'].'</td><td>'.$row['10Percentage'].'</td><td>'.$row['12Percentage'].'</td><td>'.$row['GPassYear'].'</td><td>'.$row['GUniversity'].'</td><td>'.$row['GPercentage'].'</td><td>'.$row['PGPassYear'].'</td><td>'.$row['PGUniversity'].'</td><td>'.$row['PGPercentage'].'</td><td>'.$row['NET'].'</td><td>'.$row['PHD'].'</td><td>'.$row['Publication'].'</td></tr></table>';
            }
        }
        $con->close();
    ?>
</body>
</html>