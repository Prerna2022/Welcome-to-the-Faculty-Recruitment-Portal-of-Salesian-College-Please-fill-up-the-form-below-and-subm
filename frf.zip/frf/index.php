<?php
session_start();
    $insert=false;
    if(isset($_POST['name'])){
    $server = "localhost";
    $username = "root";
    $password = "";
    $con = mysqli_connect($server, $username, $password);
    if(!$con){
        die("Database connection failed due to " . mysqli_connect_error());
    }
    else
       // echo "Database connection successful";
    $Name=$_POST['name'];
    $Age=$_POST['age'];
    $Gender=$_POST['gender'];
    $Phone=$_POST['phone'];
    $email=$_POST['email'];
    $Address=$_POST['address'];
    $Department=$_POST['department'];
    $Board10=$_POST['xboard'];
    $PassYear10=$_POST['xyear'];
    $Percentage10=$_POST['xpercentage'];
    $Board12=$_POST['xiiboard'];
    $PassYear12=$_POST['xiiyear'];
    $Percentage12=$_POST['xiipercentage'];
    $GUniversity=$_POST['guniversity'];
    $GCollege=$_POST['gcollege'];
    $GPassYear=$_POST['gyear'];
    $GPercentage=$_POST['gpercentage'];
    $PGUniversity=$_POST['pguniversity'];
    $PGPassYear=$_POST['pgyear'];
    $PGPercentage=$_POST['pgpercentage'];
    $NET=$_POST['netq'];
    $PHD=$_POST['phdq'];
    $Publication=$_POST['publication'];
    $sql = "INSERT INTO `candidates`.`application` (`Name`, `Age`, `Gender`, `Phone`, `email`, `Address`, `Department`, `10Board`, `10PassYear`, `10Percentage`, `12Board`, `12PassYear`, `12Percentage`, `GUniversity`, `GCollege`, `GPassYear`, `GPercentage`, `PGUniversity`, `PGPassYear`, `PGPercentage`, `NET`, `PHD`, `Publication`, `Date`) VALUES ('$Name', '$Age', '$Gender', '$Phone', '$email', '$Address', '$Department', '$Board10', '$PassYear10', '$Percentage10', '$Board12', '$PassYear12', '$Percentage12', '$GUniversity', '$GCollege', '$GPassYear', '$GPercentage', '$PGUniversity', '$PGPassYear', '$PGPercentage', '$NET', '$PHD', '$Publication', current_timestamp());";
    //echo $sql;
    if($con->query($sql)==true){
        //echo "Successfully inserted";
        $insert=true;
    }
    else
        echo " Error: $con->error <br>";
    $con->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Recruitment Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1> Welcome to the Faculty Recruitment Portal of Salesian College </h1>
        <p> Please fill up the form below and submit to apply for the advertised position </p>
        <?php
            if($insert==true){
                //echo "<dialog>";
                $phone=$_POST['phone'];
                $_SESSION['var']=$phone;
                echo "<p class='submitmsg'>Thanks for your interest in working with us. We will contact you soon for interview. <br></p>";
                echo '<a href="display.php">Click here to view your application</a>';
                /*if($num>0){
                    while($row=mysqli_fetch_assoc($result)){
                        echo "Candidate Serial No.".$row['Sno']."<br>"."Name: ".$row['Name']."<br>"."Age: ".$row['Age']." years"."<br>"."Gender: ".$row['Gender']."<br>"."Phone: ".$row['Phone']."<br>"."Email: ".$row['email']."<br>"."Address: ".$row['Address']."<br>Passed class 10 in the year ".$row['10PassYear']." with ".$row['10Percentage']."% of marks "."<br>Passed class 12 in the year ".$row['12PassYear']." with ".$row['12Percentage']."% of marks "."<br> Graduation details:<br>"."University- ".$row['GUniversity']."<br>College- ".$row['GCollege']."<br>Passed in the year ".$row['GPassYear']."<br>Percentage/CGPA- ".$row['GPercentage']."<br>Post Graduation details:<br> "."University- ".$row['PGUniversity']."<br> Passed in the year".$row['PGPassYear']."<br>Percentage/CGPA- ".$row['PGPercentage']."<br>Whether NET Qualified- ".$row['NET']."<br>Whether PHD- ".$row['PHD']."<br>Publications- ".$row['Publication']." ";
                        echo "<br>";
                        echo "<br>";
                    }
                }*/
                //echo "</dialog>";
            }
        ?>
        <form action="index.php" method="post">
            <input class ="personal" type="text" name="name" id="name" placeholder="Enter your full name"><br>
            <input class ="personal" type="text" name="age" id="age" placeholder="Enter your age"><br>
            <input class ="personal" type="text" name="gender" id="gender" placeholder="Gender"><br>
            <input class ="personal" type="text" name="phone" id="phone" placeholder="Enter your phone number"><br>
            <input class ="personal" type="email" name="email" id="email" placeholder="Enter your email address"><br>
            <textarea name="address" id="address" cols="30" rows="10" placeholder="Enter your current Address"></textarea>
            <br>
            <div class="otherdetails">
            <label for="department">Department</label>
            <select class="drpdn" name="department" id="department">
                <option value="null">------Select------</option>
                <option value="Education">Education</option>
                <option value="English">English</option>
                <option value="Psychology">Psychology</option>
                <option value="History">History</option>
                <option value="Political Science">Political Science</option>
                <option value="Geography">Geography</option>
                <option value="Sociology">Sociology</option>
                <option value="Physics">Physics</option>
                <option value="Computer Science & Application">Computer Science & Application</option>
                <option value="Mass Communication & Journalism">Mass Communication & Journalism</option>
                <option value="Sports Management">Sports Management</option>
                <option value="Commerce">Commerce</option>
                <option value="Economics">Economics</option>
                <option value="Vocational Studies">Vocational Studies</option>
                <option value="Physical Education">Physical Education</option>
            </select>
            <h3>Qualification</h3>
            <div class="row">
                <label for="xboard">Class 10 details</label>
                <select name="xboard" id="xboard">
                    <option value="null">------Select------</option>
                    <option value="CBSE">CBSE</option>
                    <option value="ICSE">ICSE</option>
                    <option value="WBSE">WBSE</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="xyear" id="xyear" placeholder="Year of Passing">
                <input type="text" name="xpercentage" id="xpercentage" placeholder="Enter your percentage">
            </div>
            <div class="row">
                <label for="xiiboard">Class 12 or equivalent details</label>
                <select name="xiiboard" id="xiiboard">
                    <option value="null">------Select------</option>
                    <option value="CBSE">CBSE</option>
                    <option value="ICSE">ICSE</option>
                    <option value="WBSE">WBSE</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="xiiyear" id="xiiyear" placeholder="Year of Passing">
                <input type="text" name="xiipercentage" id="xiipercentage" placeholder="Enter your percentage">
            </div>
            <div class="row">
                <label for="graduation">Graduation details</label>
                <input type="text" name="guniversity" id="guniversity" placeholder="University">
                <input type="text" name="gcollege" id="gcollege" placeholder="College">
                <input type="text" name="gyear" id="gyear" placeholder="Year of Passing">
                <input type="text" name="gpercentage" id="gpercentage" placeholder="Enter your percentage/CGPA">
            </div>
            <div class="row">
                <label for="pgraduation">Post Graduation details</label>
                <input type="text" name="pguniversity" id="pguniversity" placeholder="University">
                <input type="text" name="pgyear" id="pgyear" placeholder="Year of Passing">
                <input type="text" name="pgpercentage" id="pgpercentage" placeholder="Enter your percentage/CGPA">
            </div>
            <div class="row" name="netq">
                <label for="netq">Are you NET qualified? </label>
                <label for="netq">Yes</label>
                <input type="radio" name="netq" id="netq" value="Yes">
                <label for="netq">No</label>
                <input type="radio" name="netq" id="netq" value="No">
            </div>
            <div class="row" name="phdq">
                <label for="phdq">Are you Phd qualified? </label>
                <label for="phdq">Yes</label>
                <input type="radio" name="phdq" id="phdq" value="Yes">
                <label for="netq">No</label>
                <input type="radio" name="phdq" id="phdq" value="No">
            </div>
            <div class="row">
            <label for="publication">Publications (if any): </label>
            <input type="text" name="publication" id="publication" placeholder="Number of Publications">
            </div>
            </div>
            <button type="submit">Submit</button>
        </form>

    </div>
    <script src="index.js"></script>
</body>
</html>
