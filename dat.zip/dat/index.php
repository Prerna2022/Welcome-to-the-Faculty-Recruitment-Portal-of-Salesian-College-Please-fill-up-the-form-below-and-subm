<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="candidates";
    $con= mysqli_connect($server,$username,$password,$database);
    $sql="SELECT * FROM `application`";
    //echo $sql;
    $result = mysqli_query($con,$sql);
    if($con->query($sql)==true){
        //echo "Successfully inserted";
        //$insert=true;
    }
    else
        echo " Error: $con->error <br>";
    $num = mysqli_num_rows($result);
    /*if($num>0){
        while($row=mysqli_fetch_assoc($result)){
            echo "Candidate Serial No.".$row['Sno']."<br>"."Name: ".$row['Name']."<br>"."Age: ".$row['Age']." years"."<br>"."Gender: ".$row['Gender']."<br>"."Phone: ".$row['Phone']."<br>"."Email: ".$row['email']."<br>"."Address: ".$row['Address']."<br>Passed class 10 in the year ".$row['10PassYear']." with ".$row['10Percentage']."% of marks "."<br>Passed class 12 in the year ".$row['12PassYear']." with ".$row['12Percentage']."% of marks "."<br> Graduation details:<br>"."University- ".$row['GUniversity']."<br>College- ".$row['GCollege']."<br>Passed in the year ".$row['GPassYear']."<br>Percentage/CGPA- ".$row['GPercentage']."<br>Post Graduation details:<br> "."University- ".$row['PGUniversity']."<br> Passed in the year".$row['PGPassYear']."<br>Percentage/CGPA- ".$row['PGPercentage']."<br>Whether NET Qualified- ".$row['NET']."<br>Whether PHD- ".$row['PHD']."<br>Publications- ".$row['Publication']." ";
            echo "<br>";
            echo "<br>";
        }
    }*/
    $con->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <h1>HR Portal</h1>
   <h2>Total number of applicants till date is 
    <?php
        echo $num;    
    ?>
    </h2>
    <div class="container1">
    <form action="index.php" method="post">
    <select class="drpdn" name="dept" id="dept">
                <option value="null">------Select------</option>
                <option value="Education">Education</option>
                <option value="English">English</option>
                <option value="Psychology">Psychology</option>
                <option value="History">History</option>
                <option value="Political Science">Political Science</option>
                <option value="Geography">Geography</option>
                <option value="Sociology">Sociology</option>
                <option value="Physics">Physics</option>
                <option value="Computer Science & Application">Computer Science & Application</option>
                <option value="Mass Communication & Journalism">Mass Communication & Journalism</option>
                <option value="Sports Management">Sports Management</option>
                <option value="Commerce">Commerce</option>
                <option value="Economics">Economics</option>
                <option value="Vocational Studies">Vocational Studies</option>
                <option value="Physical Education">Physical Education</option>
            </select>
        <button type="submit">Submit</button>
        <?php
        $server="localhost";
        $username="root";
        $password="";
        $database="candidates";
        $con= mysqli_connect($server,$username,$password,$database);
        if(isset($_POST['dept'])){
            $department = $_POST['dept'];
            //echo "<br>".$department;
            $sql="SELECT * FROM `application` WHERE Department = '$department'";
            $result = mysqli_query($con,$sql);
            $num = mysqli_num_rows($result);
            echo "<br>Total number of applicants for the department of ".$department." is ".$num;

        }?>
        <div class="container2">
            <?php
                if($num>0){
                    while($row=mysqli_fetch_assoc($result)){
                        echo '<table border=1px><tr><td>Application Number</td><td>Name</td><td>Age</td><td>Phone</td><td>Email</td><td>Address</td><td>Class 10 Marks</td><td>Class 12 Marks</td><td>Graduation Year</td><td>Graduation University</td><td>Graduation Marks</td><td>Post Graduation Year</td><td>Post Graduation University</td><td>Post Graduation Marks</td><td>NET</td><td>PHD</td><td>Publication</td></tr><tr><td>'.$row['Sno'].'</td><td>'.$row['Name'].'</td><td>'.$row['Age'].'</td><td>'.$row['Phone'].'</td><td>'.$row['email'].'</td><td>'.$row['Address'].'</td><td>'.$row['10Percentage'].'</td><td>'.$row['12Percentage'].'</td><td>'.$row['GPassYear'].'</td><td>'.$row['GUniversity'].'</td><td>'.$row['GPercentage'].'</td><td>'.$row['PGPassYear'].'</td><td>'.$row['PGUniversity'].'</td><td>'.$row['PGPercentage'].'</td><td>'.$row['NET'].'</td><td>'.$row['PHD'].'</td><td>'.$row['Publication'].'</td></tr></table>';
                        echo "<br>";
                    }
                }
            ?>
        </div>
        <?php
        $con->close();
        ?>
    </form>
    </div>
</body>
</html>